
# coding: utf-8

# In[26]:


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report
import pickle #a library used to save the model


# In[27]:


from sklearn.svm import SVC


# In[58]:


from sklearn.naive_bayes import GaussianNB as nb


# In[51]:


from sklearn.neighbors import KNeighborsClassifier


# In[29]:


data=pd.read_csv("heart.csv")
data.head()


# In[30]:


data.shape


# In[31]:


data.info()


# In[32]:


data.dropna()


# In[33]:


x=data.iloc[:,:13]
x.head()


# In[34]:


x=data.drop(['target'],1)
x.head()


# In[35]:


y=data['target']
y.head()


# In[36]:


x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=7)


# In[37]:


scaler=StandardScaler()
x_train=scaler.fit_transform(x_train)
x_test=scaler.fit_transform(x_test)


# In[38]:


#Random Forest

rf_clf=RandomForestClassifier(n_estimators=10,random_state=43)
rf_clf.fit(x_train,y_train)


# In[39]:


y_pred=rf_clf.predict(x_test)
y_pred


# In[40]:


print("Accuracy Score:",accuracy_score(y_test,y_pred)*100)


# In[41]:


print("Confusion Matrix:\n",confusion_matrix(y_test,y_pred))


# In[42]:


print("Classification Report:\n",classification_report(y_test,y_pred))


# In[43]:


pickle.dump(rf_clf,open("model_rf.sav",'wb'))
pickle.dump(scaler,open("std_scaler.sav","wb"))


# In[44]:


#SVM

svm_clf=SVC()
svm_clf.fit(x_train,y_train)


# In[45]:


svm_pred=svm_clf.predict(x_test)
svm_pred


# In[46]:


print("Accuracy Score:",accuracy_score(y_test,svm_pred)*100)


# In[47]:


print("Confusion Matrix:\n",confusion_matrix(y_test,svm_pred))


# In[48]:


print("Classification Report:\n",classification_report(y_test,svm_pred))


# In[59]:


#Naive Bayes

gb_clf=nb()
gb_clf.fit(x_train,y_train)


# In[60]:


gb_pred=gb_clf.predict(x_test)
gb_pred


# In[61]:


print("Accuracy Score:",accuracy_score(y_test,gb_pred)*100)


# In[62]:


print("Confusion Matrix:\n",confusion_matrix(y_test,gb_pred))


# In[63]:


print("Classification Report:\n",classification_report(y_test,gb_pred))


# In[64]:


#KNN

knn_clf=KNeighborsClassifier()
knn_clf.fit(x_train,y_train)


# In[53]:


knn_pred=knn_clf.predict(x_test)
knn_pred


# In[54]:


print("Accuracy Score:",accuracy_score(y_test,knn_pred)*100)


# In[55]:


print("Confusion Matrix:\n",confusion_matrix(y_test,knn_pred))


# In[56]:


print("Classification Report:\n",classification_report(y_test,knn_pred))


# In[57]:


pickle.dump(knn_clf,open("model_knn.sav",'wb'))
pickle.dump(svm_clf,open("model_svm.sav",'wb'))
pickle.dump(gb_clf,open("model_gb.sav",'wb'))
